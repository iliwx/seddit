Gros Ventre font is distributed under a Creative Commons Attribution 4.0 International license.
The only condition for the free use of the font is the attribution 
of an author Dimitri Antonov / Blue Curve Designstudio in any form.

You are free to:
Share — copy and redistribute the material in any medium or format for any purpose, even commercially.
Adapt — remix, transform, and build upon the material for any purpose, even commercially.
The licensor cannot revoke these freedoms as long as you follow the license terms.
Under the following terms:

Attribution — You must give appropriate credit , provide a link to the license, and indicate if changes were made . 
You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
No additional restrictions — You may not apply legal terms or technological measures that legally restrict others 
from doing anything the license permits.
Notices:
You do not have to comply with the license for elements of the material in the public domain or where your use is 
permitted by an applicable exception or limitation .

No warranties are given. The license may not give you all of the permissions necessary for your intended use. 
For example, other rights such as publicity, privacy, or moral rights may limit how you use the material.

Notice
This deed highlights only some of the key features and terms of the actual license. It is not a license and has no 
legal value. You should carefully review all of the terms and conditions of the actual license before using the licensed material.

Creative Commons is not a law firm and does not provide legal services. Distributing, displaying, or linking to this deed or the license that it summarizes does not create a lawyer-client or any other relationship.

Creative Commons is the nonprofit behind the open licenses and other legal tools that allow creators to share their work. 
Our legal tools are free to use.




Шрифт Gros Ventre распространяется по лицензии Creative Commons Attribution 4.0 International.
Единственное условие бесплатного использования шрифта — это указание 
автора Дмитрия Антонова / Синяя Кривая Студия Дизайна в любой форме.

Вы можете свободно:
Делиться (обмениваться) — копировать и распространять материал на любом носителе и в любом формате в любых целях, включая коммерческие.
Адаптировать (создавать производные материалы) — делать ремиксы, видоизменять, и создавать новое, опираясь на этот материал в любых целях, 
включая коммерческие.
Лицензиар не вправе отозвать эти разрешения, пока вы выполняете условия лицензии.
При обязательном соблюдении следующих условий:
«Attribution» («Атрибуция») — Вы должны обеспечить соответствующее указание авторства , предоставить ссылку на лицензию, и обозначить 
изменения, если таковые были сделаны . Вы можете это делать любым разумным способом, но не таким, который подразумевал бы, что лицензиар
 одобряет вас или ваш способ использования произведения.
Без дополнительных ограничений — Вы не вправе применять юридические ограничения или технологические меры , создающие другим юридические 
препятствия в выполнении чего-либо из того, что разрешено лицензией.

Замечания:
Вы не обязаны действовать согласно условиям лицензии, если конкретная часть материала находится в общественном достоянии или если такое 
использование вами материала разрешено согласно применимому исключению или ограничению авторских прав .

Вам не даётся никаких гарантий. Лицензия может не включать все разрешения, необходимые вам для использования произведения (материала) 
по вашему замыслу. Например, иные права, такие как право на обнародование, неприкосновенность частной жизни или неимущественные права 
могут ограничить вашу возможность использовать данный материал.

https://www.behance.net/ed67b3fc
https://vk.com/public211353617

